import io
from typing import List

import matplotlib.pyplot as plt
import numpy as np
from PIL import Image


def plot_images(images: List[np.array], rows: int, columns: int) -> None:
  """This plots images in top-left to bottom right as subplots with the given rows
  and columns on an 8x8 grid.

  :param images: The set of images to render.
  :param rows: The number of rows
  :return: None
  """
  fig = plt.figure(figsize=(8, 8))
  for i in range(columns * rows):
    img = images[i]
    if img.shape[0] == 3 or img.shape[0] == 1:
      img = img.permute(1, 2, 0)
    ax = fig.add_subplot(rows, columns, i + 1)
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)
    plt.imshow(img)
  plt.show()


def get_img_from_fig(fig: plt.Figure, dpi: int = 400) -> Image:
  """A function which returns an image as PIL from a figure. This can be used to save images primarily.

  :param fig: The figure to extract the image from.
  :return: A PIL image of the figure.
  """
  buf = io.BytesIO()
  fig.savefig(buf, format="png", dpi=dpi)
  buf.seek(0)
  # img_arr = np.frombuffer(buf.getvalue(), dtype=np.uint8)

  image = Image.open(buf).convert("RGBA")
  buf.close()
  return image
