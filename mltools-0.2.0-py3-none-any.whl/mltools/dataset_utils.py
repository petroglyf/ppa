from random import randint
from typing import Any, List

from torchvision.datasets import VisionDataset


def uniform_sample(
  dataset: VisionDataset, n: int = 20, from_label: str = None
) -> List[Any]:
  """Uniformly samples a set of images a torch dataset.

  :param dataset: The dataset to sample from.
  :param n: The number of images to sample.
  :param from_label: A label to use first to sample from.
  :return: A list of data uniformly sampled from the dataset.
  """
  if from_label is None:
    # Sample randomly
    return [dataset[randint(0, len(dataset))][0] for _ in range(n)]
  else:
    # Sample from class
    raise NotImplementedError
