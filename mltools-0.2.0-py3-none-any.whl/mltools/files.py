import glob
from os import walk
from os.path import isfile, join

import msgpack
import msgpack_numpy as m
import torch

m.patch()

pickle_jar = "./dataset/pickle_jar/"


def __decode_tensor(obj):
  if b"__torch_tensor__" in obj:
    return torch.from_numpy(obj[b"as_numpy"].copy())
  return dict((key.decode("utf-8"), value) for (key, value) in obj.items())


def __encode_tensor(obj):
  # print("Type: "+ str(type(obj)))
  if isinstance(obj, type(torch.Tensor())):
    return {"__torch_tensor__": True, "as_numpy": obj.numpy()}
  return obj


def getdirs(path_in):
  f = []
  for dirpath, dirnames, filenames in walk(path_in):
    print(dirpath)
    return [dirpath + x for x in dirnames]
    # f.extend(dirnames)
    # break
  return f


def ildb_files(path_in, suffix):
  f = []
  for dirpath, dirnames, filenames in walk(path_in):
    f.extend(
      filter(
        lambda x: x.endswith(suffix),
        [dirpath + "/" + filename for filename in filenames],
      )
    )

    for dirname in dirnames:
      for dirpath, _, filenames in walk(path_in + dirname):
        f.extend(
          filter(
            lambda x: x.endswith(suffix),
            [dirpath + "/" + filename for filename in filenames],
          )
        )
  return f


def save(filename, data):
  # Write msgpack file
  path = __to_pickle_jar(filename)
  with open(path, "wb") as outfile:
    datout = msgpack.packb(data, default=__encode_tensor, use_bin_type=True)
    outfile.write(datout)


def load(filename):
  # Read msgpack file
  path = __to_pickle_jar(filename)
  with open(path, "rb") as data_file:
    data_loaded = msgpack.unpack(data_file, object_hook=__decode_tensor, raw=True)
    return data_loaded
  return None


def append(filename, to_append):
  # Read msgpack file
  base_dat = load(filename)
  assert type(to_append) == type(base_dat)
  base_dat.update(to_append)
  save(filename, base_dat)


def nglob(paths_list):
  files = []
  paths = paths_list.split(",")
  for path in paths:
    globfiles = glob.glob(path)

    # sort them
    globfiles.sort()

    files += globfiles
  return files


def __to_pickle_jar(filename):
  global pickle_jar
  if filename.startswith(pickle_jar):
    return filename
  assert not filename.endswith(".msgpack")
  # Read msgpack file
  file = join(pickle_jar, filename)
  file += ".msgpack"
  return file


def is_in_pickle_jar(filename):
  filepath = __to_pickle_jar(filename)
  return isfile(filepath)


def exists(filename):
  return isfile(filename)


def unglob_pickle_jar(filename):
  all_ = filename.split(",")
  all_files = []
  for pickle in all_:
    with_path = __to_pickle_jar(pickle)
    # with_path = join(getcwd(), with_path)
    files = nglob(with_path)
    all_files += files
  return all_files
