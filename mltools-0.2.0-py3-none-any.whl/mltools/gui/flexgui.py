#!/usr/bin/env python

# This class provides the GUI wrapper frame
# for visualizing what is going on in the model.
# It's pretty flexible and could be used for other purposes.
#

import threading
import time
from typing import Callable, Dict, List, Tuple

import kivy
import numpy as np
from kivy.app import App
from kivy.core.text import Label as CoreLabel
from kivy.core.window import Window
from kivy.graphics import Color, Line, Rectangle
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.slider import Slider
from kivy.uix.spinner import Spinner
from mltools.gui.util import timems

kivy.require("1.0.7")


class TimelineViz:
  """A class used to scrub the timeline or visualize fixed time ranges.

  This is a widget to be used in other Kivy GUIs."""

  def __init__(
    self, x, height, instruc_group, ft_ex: Dict[str, Callable[[np.ndarray], float]]
  ):
    """
    Constructor.

    :param x: position for the widget to start in.
    :param height: height of the widget
    :param instruc_group: Instructions to the user.
    """
    self.height = height
    self.width = 500

    self.feature_xtracters = ft_ex

    self.timelines = None
    self.t_init = timems()
    self.t_last = self.t_init

    self.instructs = instruc_group
    self.x = x

  def update(self, features):
    """
    Re-render the timeline widget with the updated features.

    :param features: The features to render
    """
    if self.timelines == None:
      self.timelines = [[]] * len(self.feature_xtracters)

    t_now = timems()
    if t_now - self.t_init > 2000:
      t_begin = t_now - 2000
      t_middle = t_now
      t_end = t_now + 2000
    else:
      t_begin = self.t_init
      t_middle = t_begin + 2000
      t_end = t_begin + 4000

    # print("Features: " + str(features))
    now_state = map(lambda fn: fn[1](features), self.feature_xtracters)
    # print("now state: " + str(now_state))

    for row in range(len(self.timelines)):
      numlinesinrow = len(self.timelines[row])
      # for that row, determine if start, extend, or end
      if now_state[row]:
        # continue or start
        if numlinesinrow > 0:
          # something here.. check if we should continue it or stop it
          if len(self.timelines[row][numlinesinrow - 1]) == 3:
            # start a new one - the last one had an end marker
            newlines = list(self.timelines[row])
            newlines.append([t_now, t_now])
            self.timelines[row] = newlines
          else:
            self.timelines[row][numlinesinrow - 1][1] = t_now
        else:
          # nothing on this line at all. just start a new line
          newlines = list(self.timelines[row])
          newlines.append([t_now, t_now])
          self.timelines[row] = newlines
      else:
        # end
        if numlinesinrow > 0 and len(self.timelines[row][numlinesinrow - 1]) == 2:
          # end it
          (self.timelines[row][numlinesinrow - 1]).append(None)

    # prune the lines
    self.instructs.clear()
    self.instructs.add(Color(1.0, 1.0, 1.0))
    self.instructs.add(Rectangle(size=(self.width, self.height), pos=(self.x, 0)))

    self.render_timegrid(t_begin, t_middle, t_end)

  def get_text_texture(self, textO: str, pos: Tuple[int, int]):
    """
    Creates a texture for the text at a specific position
    """
    mylabel = CoreLabel(text=text, font_size=12, color=(0, 0, 0, 1))
    # Force refresh to compute things and generate the texture
    mylabel.refresh()
    # Get the texture and the texture size
    texture = mylabel.texture
    texture_size = list(texture.size)
    # Draw the texture on any widget canvas
    return Rectangle(texture=texture, size=texture_size, pos=pos)

  def render_timegrid(self, tbegin, tmid, tend):
    tb_act = (tbegin - self.t_init) / 1000.0
    tm_act = (tmid - self.t_init) / 1000.0
    te_act = (tend - self.t_init) / 1000.0

    # Render the text
    y = 5
    x = int(0)
    textO = str("{0:.1f}".format(tb_act))
    self.instructs.add(self.get_text_texture(textO, (self.x + x, y)))

    x = (self.width / 2) - 8
    textO = str("{0:.1f}".format(tm_act))
    self.instructs.add(self.get_text_texture(textO, (self.x + x, y)))

    x = self.width - 17
    textO = str("{0:.1f}".format(te_act))
    self.instructs.add(self.get_text_texture(textO, (self.x + x, y)))

    # Render the line delineating the text at the bottom
    self.instructs.add(Color(200.0 / 255.0, 200.0 / 255.0, 200.0 / 255.0))
    self.instructs.add(Line(points=[self.x, 20, self.x + self.width, 20], width=1))

    self.instructs.add(Color(210.0 / 255.0, 210.0 / 255.0, 210.0 / 255.0))
    # Mark the seconds lines
    pt = int(tb_act)
    for _ in range(5):
      if pt > tb_act and pt < te_act:
        npt = (pt - tb_act) / 4.0
        x = npt * self.width
        self.instructs.add(
          Line(points=[self.x + x, self.height, self.x + x, 20], width=1)
        )
      pt = pt + 1

    timelinecolor = (0, 200, 200)
    y = self.height - 12
    # Actually draw the lines
    for row in range(len(self.timelines)):
      lines = self.timelines[row]
      linestokeep = list([])
      self.instructs.add(Color(rgb=timelinecolor))

      for line in lines:
        # check if the line is in bounds
        line_start = line[0]
        line_end = line[1]

        if (line_start > tbegin and line_start < tend) or (
          line_end > tbegin and line_end < tend
        ):
          # don't cull the line, it's in bounds
          linestokeep.append(line)
          line_start = max(line_start, tbegin) - tbegin
          line_end = min(line_end, tend) - tbegin

          # normalize them
          line_begin_norm = line_start / 4000.0
          line_end_norm = line_end / 4000.0

          # now fit them to the width
          x_start = line_begin_norm * self.width
          x_end = line_end_norm * self.width
          self.instructs.add(
            Line(points=[self.x + x_start, y, self.x + x_end, y], width=1)
          )

      #            self.timelines[row] = linestokeep
      label = str(self.feature_xtracters[row][0])

      self.instructs.add(self.get_text_texture(label, (self.x, y)))
      y = y - 13


class WidgetWrapper(App):
  def build(self):
    return self.mybuild

  @classmethod
  def wrapVis(cls, visualizer, timelineheight, title):
    theapp = cls()
    theapp.mybuild = visualizer
    theapp.title = title
    Window.size = (500, 300 + timelineheight)
    return theapp


class FlexGui(App):
  def build(self):
    """
    Creates the layout of the app itself.
    """

    # Create a grid layout across the whole thing
    myLayout = GridLayout(
      rows=1, cols=2, rows_minimum={0: 500}, cols_minimum={0: 150, 1: 500}
    )
    # Create a stack layout for printing on the left
    self.box = BoxLayout(orientation="vertical", padding=10)
    self.titleLabel = Label(
      halign="left",
      size_hint=(1.0, 1.0),
      text="[b][color=ff3333]Feature values:[/color][/b]",
      markup=True,
      valign="top",
    )
    self.titleLabel.bind(size=self.titleLabel.setter("text_size"))
    self.box.add_widget(self.titleLabel)

    # a map of widgets you can access later
    self.widget_map = {}

    # put the stack on the left
    myLayout.add_widget(self.box)

    # put the stack on the left
    if getattr(self, "viewer", None) is None:
      self.viewer = BoxLayout(orientation="vertical", padding=10)

    myLayout.add_widget(self.viewer)

    return myLayout

  def printLine(self, key, value):
    """
    Print a line

    """
    if self.widget_map == None:
      return
    if not key in self.widget_map.keys():
      newText = key + ": " + value
      lbl = Label(halign="left", size_hint=(1.0, 1.0), valign="top", text=newText)
      lbl.bind(size=lbl.setter("text_size"))
      self.widget_map[key] = lbl
      self.box.add_widget(lbl)
    else:
      newText = key + ": " + value
      lbl = self.widget_map[key]
      lbl.text = newText

  def __setVal(self, instance, value, toSet):  # , toSet=None, theslider=None):
    toSet.value = int(value)

  def createSliderInt(self, name, minV, maxV, defaultVal=0):
    if self.widget_map == None:
      return
    if not name in self.widget_map.keys():
      newText = name + ":"
      boxlayout = BoxLayout(orientation="horizontal", padding=0, halign="left")
      lbl = Label(halign="left", size_hint=(1.0, 1.0), valign="top", text=newText)
      lbl.bind(size=lbl.setter("text_size"))

      # I can't believe this works. (NBD)
      valOut = lambda: None
      valOut.value = int(defaultVal)

      numslider = None
      numslider = Slider(min=minV, max=maxV, value=defaultVal)
      numslider.bind(value=lambda x, y: self.__setVal(x, y, valOut))
      boxlayout.add_widget(lbl)
      boxlayout.add_widget(numslider)

      self.widget_map[name] = valOut
      self.box.add_widget(boxlayout)
      return valOut
    return None

  def addDropDown(self, name: str, options: List, onSelect):
    if self.widget_map == None:
      return
    if not name in self.widget_map.keys():
      spinner = Spinner(
        # default value shown
        text=options[0],
        # available values
        values=options,
        # just for positioning in our example
        size_hint=(None, None),
        size=(100, 44),
        pos_hint={"center_x": 0.5, "center_y": 0.0},
      )

      def show_selected_value(_, text):
        onSelect(text)

      spinner.bind(text=show_selected_value)

      self.widget_map[name] = spinner
      self.viewer.add_widget(spinner)
      return spinner
    return None


# Simple test to make sure just this flexible GUI works.
if __name__ == "__main__":
  gui = FlexGui()
  gui.title = "Example app"

  def addAbutton():
    time.sleep(1.0)
    gui.addDropDown(
      "pulldown",
      ["hello", "world", "foo", "bar"],
      lambda op: print("Got it: " + str(op)),
    )
    time.sleep(1.0)
    print("Adding..")
    gui.printLine("Test", "Test Value")
    time.sleep(1.0)
    print("Changing..")
    gui.printLine("Test", "Test Value 2")

  threading.Thread(target=addAbutton).start()
  gui.run()
