import time


def timems() -> int:
  """Returns the time in milliseconds.

  :return: The time in milliseconds."""
  return int(round(time.time() * 1000))


def is_interactive() -> bool:
  """Returns whether the interpreter is running or is in iPython/Jupyter.

  :return: Whether the interpreter is running."""
  import __main__ as main

  return not hasattr(main, "__file__")
