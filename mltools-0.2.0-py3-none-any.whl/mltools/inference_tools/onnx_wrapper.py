import logging
from pathlib import Path
from typing import Dict

import jax.numpy as jnp
import numpy as np
import onnx
from onnxruntime import InferenceSession, get_available_providers


class NumpyOnnxWrapper:
  """This performs initialization of ONNX to use the best inference engine possible. It primarily will operate only on numpy types."""

  def __init__(self, onnx_filepath: Path):
    """Constructor for the class

    :param onnx_filepath: The path to an onnx file to load.
    :raises FileNotFound: If the path provided does not exist.
    """
    self.model = onnx.load(onnx_filepath)
    available_providers = get_available_providers()
    if "TensorrtExecutionProvider" in available_providers:
      self.provider = "TensorrtExecutionProvider"
    elif "CUDAExecutionProvider" in available_providers:
      self.provider = "CUDAExecutionProvider"
    elif "CoreMLExecutionProvider" in available_providers:
      self.provider = "CoreMLExecutionProvider"
    else:
      self.provider = "CPUExecutionProvider"
    self.session = InferenceSession(
      self.model.SerializeToString(), providers=[self.provider]
    )
    logging.info("Using ONNX provider: " + self.provider)

  def forward(self, np_patch_in: Dict[str, np.array]) -> np.array:
    """Perform a forward pass of the onnx model.

    :param np_patch_in: ONNX takes a set of parameter names and values. The values must be numpy arrays.
    :return: The first output value from the forward pass of the model.
    """
    outp = self.session.run(["y"], np_patch_in)
    outp = outp[0]
    return outp


class JAXOnnxWrapper(NumpyOnnxWrapper):
  """This performs initialization of ONNX to use the best inference engine possible. It primarily will operate only on JAX types for convienience."""

  def __init__(self, onnx_filepath: Path):
    """Constructor for the class

    :param onnx_filepath: The path to an onnx file to load.
    :raises FileNotFound: If the path provided does not exist.
    """
    super().__init__(onnx_filepath)

  def get_features(self, jax_patch_in: Dict[str, jnp.array]) -> jnp.array:
    """Perform a forward pass of the onnx model.

    :param jax_patch_in: ONNX takes a set of parameter names and values. The values must be JAX arrays.
    :return: The first output value from the forward pass of the model.
    """
    output_value = super().get_features(np.array(jax_patch_in))
    return jnp.array(output_value)
