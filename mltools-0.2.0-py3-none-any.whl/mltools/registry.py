from typing import Any, Callable, Dict, Generic, List, TypeVar

T = TypeVar("T")


class Registry(Generic[T]):
  """A class for registering multiple paths through the experiment in an object oriented way."""

  def __init__(self) -> None:
    """Constructor for the registry."""
    self._register: Dict[str, Callable[[Any], T]] = {}

  def register(
    self,
    name: str,
    dataset_constructor: Callable[[Any], T],
  ):
    """Adds an item to the registry.

    :param name: The name of the item in the registry.
    :param dataset_constructor: A constructor to create the object of interest.
    """
    self._register[name] = dataset_constructor

  def get(self, name: str) -> Callable[[Any], T] | None:
    """Gets an item's constructor from the registry.

    :param name: The name of the item in the registry.
    :return: A constructor to create the object of interest.
    """
    if name in self._register:
      return self._register[name]
    return None

  def all_registered(self) -> List[str]:
    """Gets an item's constructor from the registry.

    :return: A list of all the items in the registry that could be retrieved.
    """
    return list(self._register.keys())
