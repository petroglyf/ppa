import jax.numpy as jnp

# from motion.retarget.RetargetMap import interleave
# from robot.basic_robot import Robot


def pairwise_dist(x: jnp.array, y: jnp.array) -> jnp.array:
  """Uniformly samples a set of images a torch dataset.

  :param dataset: The dataset to sample from.
  :param n: The number of images to sample.
  :param from_label: A label to use first to sample from.
  :return: A list of data uniformly sampled from the dataset.
  """
  xx, yy, zz = jnp.matmul(x, x.t()), jnp.matmul(y, y.t()), jnp.matmul(x, y.t())
  rx = xx.diag().unsqueeze(0).expand_as(zz.t())
  ry = yy.diag().unsqueeze(0).expand_as(zz)
  P = rx.t() + ry - 2 * zz
  return P


# def forward_kinematics(remapped: Iterable, robot: Robot, period=1.0/120.0, just_right_arm=True):
#     replay_buffer = []
#     # stride = round(len(target_motion) / policy.steps_to_terminate())
#     target_indices = get_target_indices(robot)
#     remapped_iter = iter(remapped)
#     action = next(remapped_iter)
#     target_indices[4] = 60
#     while not action is None:
#         # Get controls
#         # print("action: " + str(action))
#         # action[0] = math.fabs(action[0])
#         # # action[5] = -math.fabs(action[5])
#         action = action.copy()
#         if just_right_arm:
#             action[5:] = 0.
#         # action[5] = math.pi/2.
#         target_controls = interleave(action, robot.nJoints, target_indices)
#         target_controls = target_controls.detach().numpy()

#         # Set joints and get state
#         # robot.setDesiredPoseSorted(target_controls)
#         # robot.stepIntoFuture()

#         robot.DONTUSEINPLAYBACK_ForwardK(target_controls)
#         kine = robot.getKinematics()

#         # Record
#         # diag.update(target_indices)
#         replay_buffer.append(kine[:, :3])
#         try:
#             action = next(remapped_iter)
#         except StopIteration:
#             action = None

#     # Add time stamps
#     replay_buffer = zip([i * period for i in range(len(replay_buffer))],
#                         replay_buffer)
#     return replay_buffer
